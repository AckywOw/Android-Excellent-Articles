
package com.example.testjar;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;

public class TestUtilJar extends Activity {

    private ImageView imageView;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(MResource.getIdByName(getApplication(), "layout", "jar_activity_main"));
        context = this;
        imageView = (ImageView) findViewById(MResource.getIdByName(getApplication(), "id",
                "jar_imageView"));
        imageView.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Toast.makeText(
                        context,
                        "jar = "
                                + getApplication().getString(
                                        MResource.getIdByName(getApplication(), "string",
                                                "jar_test_name")), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
