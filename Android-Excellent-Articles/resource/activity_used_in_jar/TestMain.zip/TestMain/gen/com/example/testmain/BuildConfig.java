/** Automatically generated file. DO NOT MODIFY */
package com.example.testmain;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}